import wget

def download_links(file_path):
    with open(file_path, 'r') as file:
        links = file.readlines()

        for link in links:
            link = link.strip()
            try:
                print(f"Downloading: {link}")
                wget.download(link)
                print("Download successful!")
            except Exception as e:
                print(f"Failed to download {link}: {e}")

if __name__ == "__main__":
    file_path = "list.txt"
    download_links(file_path)
