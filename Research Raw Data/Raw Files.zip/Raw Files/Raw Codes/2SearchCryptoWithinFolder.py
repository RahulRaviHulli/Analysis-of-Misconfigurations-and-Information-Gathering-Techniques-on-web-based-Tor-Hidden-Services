import os
import re

def search_crypto_addresses(folder_path):
    # Regular expression for detecting common cryptocurrency addresses
    crypto_address_pattern = r'\b(?:[13][a-km-zA-HJ-NP-Z0-9]{26,35}|bc1(?:[ac-hj-np-z02-9]{5,39}))\b'

    for root, dirs, files in os.walk(folder_path):
        for file_name in files:
            file_path = os.path.join(root, file_name)

            try:
                with open(file_path, 'r', errors='ignore') as file:
                    content = file.read()
                    addresses = re.findall(crypto_address_pattern, content)

                    if addresses:
                        print(f"File: {file_path}")
                        print("Cryptocurrency Addresses found:")
                        for address in addresses:
                            print(f"- {address}")
                        print("\n")
            except Exception as e:
                print(f"Error reading file {file_path}: {e}")

if __name__ == "__main__":
    folder_path = "/path/to/your/folder"
    search_crypto_addresses(folder_path)
