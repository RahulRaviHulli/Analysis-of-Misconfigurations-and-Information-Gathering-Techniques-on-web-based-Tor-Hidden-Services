import os
import requests

def validate_address_online(address, blockchain="btc"):
    # This function validates a cryptocurrency address using an online blockchain explorer
    base_url = f"https://api.blockchair.com/{blockchain}/dashboards/address/{address}"

    try:
        response = requests.get(base_url)
        data = response.json()

        if 'data' in data and 'address' in data['data']:
            return data['data']['address']['transactions_count'] > 0
    except Exception as e:
        print(f"Error validating address online: {e}")

    return False

def process_addresses(input_file_path, output_file_path):
    with open(input_file_path, 'r') as input_file:
        addresses = input_file.readlines()

    output_lines = []

    for address in addresses:
        address = address.strip()
        output_line = f"{address}: "
        if validate_address_online(address):
            output_line += "Valid address with transactions"
        else:
            output_line += "Valid address with no transactions"
        output_lines.append(output_line)

    with open(output_file_path, 'w') as output_file:
        output_file.write('\n'.join(output_lines))

if __name__ == "__main__":
    input_file_path = "list.txt"
    output_file_path = "crypto.txt"
    process_addresses(input_file_path, output_file_path)
