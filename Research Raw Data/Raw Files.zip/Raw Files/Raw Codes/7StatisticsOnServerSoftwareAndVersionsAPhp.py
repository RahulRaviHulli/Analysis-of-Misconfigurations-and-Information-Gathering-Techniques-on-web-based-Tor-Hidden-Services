import os
import requests

def get_server_info(url):
    try:
        response = requests.head(url, allow_redirects=True)
        response.raise_for_status()

        server_info = response.headers.get('Server')
        return server_info

    except requests.RequestException as e:
        print(f"Error fetching data from {url}: {e}")
        return None

def process_onion_websites(folder_path, output_file_path):
    onion_websites = [f for f in os.listdir(folder_path) if f.endswith('.onion')]

    with open(output_file_path, 'w') as output_file:
        output_file.write("Website\tServer Info\n")

        for onion_website in onion_websites:
            website_url = f"http://{onion_website}"

            server_info = get_server_info(website_url)

            if server_info:
                output_file.write(f"{onion_website}\t{server_info}\n")

if __name__ == "__main__":
    folder_path = "/path/to/your/websites"
    output_file_path = "ServerInfo.txt"
    process_onion_websites(folder_path, output_file_path)
