import os
import re
import requests
from bs4 import BeautifulSoup

def extract_contact_info(url):
    try:
        response = requests.get(url)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, 'html.parser')

        # Extract phone numbers
        phone_numbers = re.findall(r'\b(?:\+\d{1,2}\s?)?(\d{10,15})\b', soup.get_text())

        # Extract email addresses
        email_addresses = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', soup.get_text())

        return phone_numbers, email_addresses

    except requests.RequestException as e:
        print(f"Error fetching data from {url}: {e}")
        return None, None

def process_onion_websites(input_file_path, output_file_path):
    with open(input_file_path, 'r') as input_file:
        onion_websites = input_file.readlines()

    with open(output_file_path, 'w') as output_file:
        output_file.write("Onion Website\tPhone Numbers\tEmail Addresses\n")

        for onion_website in onion_websites:
            onion_website = onion_website.strip()

            if not onion_website.startswith("http://") and not onion_website.startswith("https://"):
                onion_website = "http://" + onion_website

            phone_numbers, email_addresses = extract_contact_info(onion_website)

            if phone_numbers or email_addresses:
                output_file.write(f"{onion_website}\t{', '.join(phone_numbers)}\t{', '.join(email_addresses)}\n")
            else:
                output_file.write(f"{onion_website}\tNo contact information found\n")

if __name__ == "__main__":
    input_file_path = "list.txt"
    output_file_path = "ContactInfo.txt"
    process_onion_websites(input_file_path, output_file_path)
