import os
import re

def find_framework_info(content):
    php_frameworks = {
        'Laravel': r'\bLaravel\b',
        'Symfony': r'\bSymfony\b',
        'CodeIgniter': r'\bCodeIgniter\b',
        'Yii': r'\bYii\b',
        'Zend': r'\bZend\b',
        # Add more frameworks and patterns as needed
    }

    for framework, pattern in php_frameworks.items():
        match = re.search(pattern, content, re.IGNORECASE)
        if match:
            return framework

    return None

def process_onion_websites(folder_path, output_file_path):
    onion_websites = [f for f in os.listdir(folder_path) if f.endswith('.onion')]

    with open(output_file_path, 'w') as output_file:
        output_file.write("Website\tFramework Info\n")

        for onion_website in onion_websites:
            website_path = os.path.join(folder_path, onion_website)

            try:
                with open(website_path, 'r', errors='ignore') as file:
                    content = file.read()

                    framework_info = find_framework_info(content)

                    if framework_info:
                        output_file.write(f"{onion_website}\t{framework_info}\n")
                    else:
                        output_file.write(f"{onion_website}\tNo PHP framework information found\n")
            except Exception as e:
                print(f"Error processing {onion_website}: {e}")

if __name__ == "__main__":
    folder_path = "/path/to/your/websites"
    output_file_path = "FrameworkInfo.txt"
    process_onion_websites(folder_path, output_file_path)
