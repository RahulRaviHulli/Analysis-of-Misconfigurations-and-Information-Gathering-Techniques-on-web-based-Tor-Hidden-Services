import os
import re
import requests
from bs4 import BeautifulSoup

def get_wordpress_plugins_info(url):
    try:
        response = requests.get(url)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, 'html.parser')

        plugin_elements = soup.find_all('tr', class_='plugin-update-tr')
        plugins_info = {}

        for plugin_element in plugin_elements:
            plugin_name = plugin_element.find('td', class_='plugin-title').find('strong').text.strip()
            plugin_version = plugin_element.find('td', class_='plugin-title').find('span', class_='version').text.strip()
            plugins_info[plugin_name] = plugin_version

        return plugins_info

    except requests.RequestException as e:
        print(f"Error fetching data from {url}: {e}")
        return None

def process_onion_websites(folder_path, output_file_path):
    onion_websites = [f for f in os.listdir(folder_path) if f.endswith('.onion')]

    with open(output_file_path, 'w') as output_file:
        output_file.write("Website\tPlugin Name\tVersion\n")

        for onion_website in onion_websites:
            website_url = f"http://{onion_website}"

            plugins_info = get_wordpress_plugins_info(website_url)

            if plugins_info:
                for plugin_name, plugin_version in plugins_info.items():
                    output_file.write(f"{onion_website}\t{plugin_name}\t{plugin_version}\n")

if __name__ == "__main__":
    folder_path = "/path/to/your/websites"
    output_file_path = "WordPressPluginsInfo.txt"
    process_onion_websites(folder_path, output_file_path)
