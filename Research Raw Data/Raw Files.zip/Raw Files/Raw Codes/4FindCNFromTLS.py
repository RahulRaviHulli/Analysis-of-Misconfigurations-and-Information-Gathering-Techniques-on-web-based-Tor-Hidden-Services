import ssl
import socket

def get_common_name(hostname):
    context = ssl.create_default_context()

    with socket.create_connection((hostname, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()

    # The Common Name is often found in the 'subject' field of the certificate
    for sub in cert['subject']:
        for key, value in sub:
            if key == 'commonName':
                return value

    return None

def process_urls(input_file_path, output_file_path):
    with open(input_file_path, 'r') as input_file:
        urls = input_file.readlines()

    cn_results = []

    for url in urls:
        url = url.strip()
        common_name = get_common_name(url)
        cn_results.append(f"{url}: {common_name}")

    with open(output_file_path, 'w') as output_file:
        output_file.write('\n'.join(cn_results))

if __name__ == "__main__":
    input_file_path = "list.txt"
    output_file_path = "CN.txt"
    process_urls(input_file_path, output_file_path)
