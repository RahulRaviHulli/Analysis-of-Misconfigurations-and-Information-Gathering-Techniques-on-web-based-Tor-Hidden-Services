import os
import re

def find_database_info(content):
    # This is a simple example, and it may not cover all cases
    # You might need to adjust it based on the specific patterns or files related to the SQL database you are looking for
    sql_patterns = [
        r'\bmysql\b',
        r'\bMariaDB\b',
        r'\bSQLite\b',
        r'\bPostgreSQL\b',
        r'\bMicrosoft SQL Server\b',
        # Add more patterns as needed
    ]

    for pattern in sql_patterns:
        match = re.search(pattern, content, re.IGNORECASE)
        if match:
            return match.group()

    return None

def process_onion_websites(folder_path, output_file_path):
    onion_websites = [f for f in os.listdir(folder_path) if f.endswith('.onion')]

    with open(output_file_path, 'w') as output_file:
        output_file.write("Website\tDatabase Info\n")

        for onion_website in onion_websites:
            website_path = os.path.join(folder_path, onion_website)

            try:
                with open(website_path, 'r', errors='ignore') as file:
                    content = file.read()

                    database_info = find_database_info(content)

                    if database_info:
                        output_file.write(f"{onion_website}\t{database_info}\n")
                    else:
                        output_file.write(f"{onion_website}\tNo database information found\n")
            except Exception as e:
                print(f"Error processing {onion_website}: {e}")

if __name__ == "__main__":
    folder_path = "/path/to/your/websites"
    output_file_path = "DatabaseInfo.txt"
    process_onion_websites(folder_path, output_file_path)
