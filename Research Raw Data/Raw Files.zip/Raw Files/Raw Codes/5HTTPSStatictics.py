import requests

def collect_web_stats(input_file_path, output_file_path):
    with open(input_file_path, 'r') as input_file:
        urls = input_file.readlines()

    status_code_counts = {}

    for url in urls:
        url = url.strip()
        try:
            response = requests.get(url, timeout=5)
            status_code = response.status_code

            if status_code in status_code_counts:
                status_code_counts[status_code] += 1
            else:
                status_code_counts[status_code] = 1

            print(f"URL: {url}, Status Code: {status_code}")
        except requests.RequestException as e:
            print(f"URL: {url}, Error: {e}")

    with open(output_file_path, 'w') as output_file:
        output_file.write("Status Code\tCount\n")
        for code, count in sorted(status_code_counts.items()):
            output_file.write(f"{code}\t\t{count}\n")

if __name__ == "__main__":
    input_file_path = "list.txt"
    output_file_path = "WebStats.txt"
    collect_web_stats(input_file_path, output_file_path)
